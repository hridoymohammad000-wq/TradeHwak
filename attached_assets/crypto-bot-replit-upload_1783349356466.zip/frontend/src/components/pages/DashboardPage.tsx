import React, { useEffect, useState } from 'react';
import {
  Card,
  EmptyState,
  PageHeader,
  SectionHeader,
  StatusBadge,
} from '../UIFoundation';
import { backendApi } from '../../api/services';
import type { BybitMarketSnapshotData, DashboardSummaryData, HealthData } from '../../api/types';
import type { BackendStatus } from '../../App';
import { Database, Zap, Cpu, BellRing, AlertTriangle, LoaderCircle } from 'lucide-react';

function formatCount(value: number) {
  return value.toLocaleString();
}

export function DashboardPage({ backendStatus }: { backendStatus: BackendStatus }) {
  const [summary, setSummary] = useState<DashboardSummaryData | null>(null);
  const [health, setHealth] = useState<HealthData | null>(null);
  const [marketSnapshot, setMarketSnapshot] = useState<BybitMarketSnapshotData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();

    async function loadDashboard() {
      if (backendStatus !== 'healthy') {
        setSummary(null);
        setHealth(null);
        setMarketSnapshot(null);
        setError(backendStatus === 'error' ? 'Backend unavailable' : null);
        setIsLoading(backendStatus === 'loading');
        return;
      }
      try {
        setIsLoading(true);
        setError(null);
        const [summaryResponse, healthResponse, marketSnapshotResponse] = await Promise.all([
          backendApi.getDashboardSummary(controller.signal),
          backendApi.getHealth(controller.signal),
          backendApi.getBybitMarketSnapshot('BTCUSDT', controller.signal),
        ]);
        setSummary(summaryResponse.data);
        setHealth(healthResponse.data);
        setMarketSnapshot(marketSnapshotResponse.data);
      } catch (loadError) {
        setError(loadError instanceof Error ? loadError.message : 'Failed to load dashboard summary');
      } finally {
        setIsLoading(false);
      }
    }

    void loadDashboard();
    return () => controller.abort();
  }, [backendStatus]);

  const guiBadge =
    error
      ? { status: 'danger' as const, label: 'Backend Offline' }
      : isLoading
        ? { status: 'pending' as const, label: 'Loading' }
        : { status: 'active' as const, label: 'Connected' };

  const diagnostics = [
    {
      icon: Database,
      label: 'Backend Phase',
      status: health?.phase === 'foundation' ? 'pending' : 'active',
      value: health?.phase || 'Pending',
    },
    {
      icon: Zap,
      label: 'Execution Engine',
      status: health?.execution_enabled ? 'active' : 'inactive',
      value: health?.execution_enabled ? 'Enabled' : 'Disabled',
    },
    {
      icon: Cpu,
      label: 'Scalping Engine',
      status: summary?.scalping_engine_enabled ? 'active' : 'inactive',
      value: summary?.scalping_engine_enabled ? 'Enabled' : 'Disabled',
    },
    {
      icon: BellRing,
      label: 'Intraday Engine',
      status: summary?.intraday_engine_enabled ? 'active' : 'inactive',
      value: summary?.intraday_engine_enabled ? 'Enabled' : 'Disabled',
    },
  ];

  const formatMarketValue = (value: number | null, digits = 2) =>
    value === null ? 'No Data' : value.toFixed(digits);

  return (
    <div className="space-y-8">
      <PageHeader
        title="Dashboard Console"
        description="System telemetry, daemon logs, and dual-strategy coordination."
        action={
          <div className="flex items-center gap-3">
            <span className="text-xs text-slate-500 uppercase font-mono font-bold">GUI State:</span>
            <StatusBadge status={guiBadge.status} label={guiBadge.label} />
          </div>
        }
      />

      <div className="space-y-4">
        <SectionHeader title="Today's Session Performance Summary" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card title="Active Trades Open">
            <div className="py-2">
              <span className="text-lg font-bold font-mono text-slate-200 uppercase">
                {summary ? formatCount(summary.today_summary.total_open_trades) : 'No Data'}
              </span>
              <p className="text-xs text-slate-500 mt-2 font-sans">
                {summary ? 'Live count from backend summary' : 'Waiting for backend integration'}
              </p>
            </div>
          </Card>
          <Card title="Closed Trades Today">
            <div className="py-2">
              <span className="text-lg font-bold font-mono text-slate-200 uppercase">
                {summary ? formatCount(summary.today_summary.closed_trades_today) : 'No Data'}
              </span>
              <p className="text-xs text-slate-500 mt-2 font-sans">
                {summary ? 'Backend-provided trade completion count' : 'Waiting for backend integration'}
              </p>
            </div>
          </Card>
          <Card title="Strategy Mode">
            <div className="py-2">
              <span className="text-lg font-bold font-mono text-slate-200 uppercase">
                {summary?.active_strategy_mode || 'No Data'}
              </span>
              <p className="text-xs text-slate-500 mt-2 font-sans">
                Current backend-selected strategy mode
              </p>
            </div>
          </Card>
          <Card title="System Mode">
            <div className="py-2">
              <span className="text-lg font-bold font-mono text-slate-200 uppercase">
                {summary?.system_mode || 'No Data'}
              </span>
              <p className="text-xs text-slate-500 mt-2 font-sans">
                Demo/live mode from backend runtime state
              </p>
            </div>
          </Card>
        </div>
      </div>

      {isLoading && (
        <EmptyState
          title="Loading dashboard summary"
          description="Fetching backend dashboard state."
          icon={<LoaderCircle size={24} className="animate-spin" />}
        />
      )}

      {!isLoading && error && (
        <EmptyState
          title="Failed to load dashboard summary"
          description={error}
          icon={<AlertTriangle size={24} />}
        />
      )}

      {!isLoading && !error && summary && (
        <>
          <div className="space-y-4">
            <SectionHeader title="Bybit Demo Market Snapshot" />
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card title={marketSnapshot?.symbol || 'BTCUSDT'}>
                <div className="py-2">
                  <span className="text-lg font-bold font-mono text-slate-200 uppercase">
                    {formatMarketValue(marketSnapshot?.last_price ?? null, 4)}
                  </span>
                  <p className="text-xs text-slate-500 mt-2 font-sans">Last traded price</p>
                </div>
              </Card>
              <Card title="24H Change">
                <div className="py-2">
                  <span className="text-lg font-bold font-mono text-slate-200 uppercase">
                    {marketSnapshot?.price_change_percent_24h !== null && marketSnapshot?.price_change_percent_24h !== undefined
                      ? `${(marketSnapshot.price_change_percent_24h * 100).toFixed(2)}%`
                      : 'No Data'}
                  </span>
                  <p className="text-xs text-slate-500 mt-2 font-sans">Realtime Bybit ticker move</p>
                </div>
              </Card>
              <Card title="Bid / Ask">
                <div className="py-2 space-y-2">
                  <div className="flex justify-between gap-3 text-xs font-mono">
                    <span className="text-slate-500">Bid</span>
                    <span className="text-slate-200">{formatMarketValue(marketSnapshot?.best_bid_price ?? null, 4)}</span>
                  </div>
                  <div className="flex justify-between gap-3 text-xs font-mono">
                    <span className="text-slate-500">Ask</span>
                    <span className="text-slate-200">{formatMarketValue(marketSnapshot?.best_ask_price ?? null, 4)}</span>
                  </div>
                </div>
              </Card>
              <Card title="Spread">
                <div className="py-2">
                  <span className="text-lg font-bold font-mono text-slate-200 uppercase">
                    {marketSnapshot?.spread_percent !== null && marketSnapshot?.spread_percent !== undefined
                      ? `${marketSnapshot.spread_percent.toFixed(4)}%`
                      : 'No Data'}
                  </span>
                  <p className="text-xs text-slate-500 mt-2 font-sans">
                    {marketSnapshot?.fetched_at || 'Waiting for Bybit response'}
                  </p>
                </div>
              </Card>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-4">
              <SectionHeader title="Engine Workflow Coordination" />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-slate-900/40 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold uppercase tracking-wider text-purple-400 font-mono">SCALPING MODULE</span>
                      <StatusBadge
                        status={summary.scalping_engine_enabled ? 'active' : 'inactive'}
                        label={summary.scalping_engine_enabled ? 'Enabled' : 'Disabled'}
                      />
                    </div>
                    <h3 className="text-base font-bold text-slate-200">Ultra-Fast Order Matching</h3>
                    <p className="text-xs text-slate-400 font-sans leading-relaxed">
                      Phase 1 integration uses backend engine state only. Market execution remains disabled.
                    </p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-800/60 font-mono text-[10px] text-slate-500 flex justify-between">
                    <span className="uppercase font-bold">{summary.active_strategy_mode === 'scalping' ? 'Primary Mode' : 'Standby'}</span>
                  </div>
                </div>
                <div className="bg-slate-900/40 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold uppercase tracking-wider text-blue-400 font-mono">INTRADAY MODULE</span>
                      <StatusBadge
                        status={summary.intraday_engine_enabled ? 'active' : 'inactive'}
                        label={summary.intraday_engine_enabled ? 'Enabled' : 'Disabled'}
                      />
                    </div>
                    <h3 className="text-base font-bold text-slate-200">Macro Breakout Strategy</h3>
                    <p className="text-xs text-slate-400 font-sans leading-relaxed">
                      Backend status is connected, but real scanner and chart feeds remain placeholder-safe in Phase 1.
                    </p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-800/60 font-mono text-[10px] text-slate-500 flex justify-between">
                    <span className="uppercase font-bold">{summary.active_strategy_mode === 'intraday' ? 'Primary Mode' : 'Standby'}</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="space-y-4">
              <SectionHeader title="Subsystem Diagnostics" />
              <div className="space-y-3.5 bg-slate-900/40 border border-slate-800/80 rounded-lg p-4">
                {diagnostics.map(({ icon: Icon, label, status, value }) => (
                  <div key={label} className="flex items-center justify-between p-2.5 rounded bg-slate-950/30 border border-slate-900">
                    <div className="flex items-center gap-2.5">
                      <Icon size={16} className="text-slate-500" />
                      <span className="text-xs font-semibold text-slate-300 font-mono">{label}</span>
                    </div>
                    <StatusBadge
                      status={status as 'active' | 'inactive' | 'pending'}
                      label={value}
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <SectionHeader title="Operator Telemetry Logs" />
            {summary.recent_events.length > 0 ? (
              <div className="space-y-3">
                {summary.recent_events.map((event, index) => (
                  <div key={`${event.event_type}-${index}`} className="rounded border border-slate-800 bg-slate-900/30 p-4">
                    <div className="flex items-center justify-between gap-3">
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-300 font-mono">
                        {event.event_type}
                      </span>
                      <span className="text-[10px] uppercase text-slate-500 font-mono">
                        {event.created_at || 'Timestamp unavailable'}
                      </span>
                    </div>
                    <p className="mt-2 text-sm text-slate-400 font-sans">{event.message}</p>
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState
                title="Waiting for backend integration"
                description="No operational events are being emitted yet."
              />
            )}
          </div>
        </>
      )}
    </div>
  );
}
