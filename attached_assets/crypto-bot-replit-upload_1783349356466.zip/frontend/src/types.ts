/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum ActivePage {
  DASHBOARD = 'dashboard',
  SCANNER = 'scanner',
  SIGNALS = 'signals',
  CHART = 'chart',
  ACTIVE_TRADES = 'active_trades',
  JOURNAL = 'journal',
  SETTINGS = 'settings'
}

export type { Direction, RuntimeMode, Timeframe, TradingMode } from './api/types';
