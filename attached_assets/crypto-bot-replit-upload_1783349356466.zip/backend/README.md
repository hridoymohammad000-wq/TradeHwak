# Crypto Scalping Trader Backend

Backend-only FastAPI foundation for a future crypto trading system that will support scalping and intraday workflows. This phase focuses on stable API contracts, clean in-memory runtime state, and frontend integration readiness without live exchange connectivity.

## Current phase

- `foundation`
- execution remains disabled
- scanner, signals, journal, and chart context stay placeholder-safe

## Folder structure

- `app/api/` route modules and router registration
- `app/core/` config, shared state wiring, and exception handling
- `app/models/` internal runtime models
- `app/schemas/` request and response models
- `app/services/` in-memory business logic and response shaping

## Local setup

Create a virtual environment:

```powershell
python -m venv .venv
```

Activate it:

```powershell
.\.venv\Scripts\Activate.ps1
```

Install dependencies:

```powershell
pip install -r requirements.txt
```

Run the server:

```powershell
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload
```

## Available endpoints

- `GET /health`
- `GET /mode`
- `GET /dashboard-summary`
- `GET /settings`
- `GET /settings/view`
- `POST /settings`
- `POST /scan`
- `GET /signals`
- `GET /active-trades`
- `GET /closed-trades`
- `GET /chart-context`
- `POST /engine/control`
