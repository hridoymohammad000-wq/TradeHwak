"""Internal domain models."""
