from fastapi import HTTPException

from app.schemas.scanner import ScanData, ScanRequest, ScanResponse, ScanResult
from app.services.settings_service import SettingsService
from app.services.strategy_service import StrategyService


class ScannerService:
    def __init__(
        self,
        settings_service: SettingsService,
        strategy_service: StrategyService,
    ) -> None:
        self._settings_service = settings_service
        self._strategy_service = strategy_service

    def scan(self, payload: ScanRequest | None) -> ScanResponse:
        request = payload or ScanRequest()
        selected_mode = (
            request.mode
            or self._settings_service.get_mode_summary().data.active_strategy_mode
        )
        symbols = request.symbols or self._strategy_service.default_symbols(selected_mode)
        filtered_results: list[ScanResult] = []

        for symbol in symbols:
            try:
                signal = self._strategy_service.evaluate_symbol(
                    symbol=symbol,
                    mode=selected_mode,
                    timeframe=request.timeframe,
                )
            except HTTPException:
                continue
            if signal is None:
                continue
            if request.direction is not None and signal.direction != request.direction:
                continue
            if request.grade is not None and signal.grade != request.grade:
                continue
            filtered_results.append(
                ScanResult(
                    symbol=signal.symbol,
                    mode=signal.mode,
                    timeframe=signal.timeframe,
                    direction=signal.direction,
                    grade=signal.grade,
                    reason=signal.reason,
                )
            )

        return ScanResponse(
            message="Scan completed.",
            data=ScanData(
                mode=selected_mode,
                timeframe=request.timeframe or self._strategy_service.default_timeframe(selected_mode),
                results=filtered_results,
            ),
        )
