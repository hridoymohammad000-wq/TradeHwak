from app.services.auto_trade_service import AutoTradeService
from app.services.bybit_service import BybitService
from app.services.dashboard_service import DashboardService
from app.services.chart_context_service import ChartContextService
from app.services.engine_service import EngineService
from app.services.manual_trade_service import ManualTradeService
from app.services.scanner_service import ScannerService
from app.services.settings_service import SettingsService
from app.services.signals_service import SignalsService
from app.services.strategy_service import StrategyService
from app.services.system_service import SystemService
from app.services.trade_service import TradeService


settings_service = SettingsService()
system_service = SystemService()
bybit_service = BybitService()
strategy_service = StrategyService(bybit_service=bybit_service)
scanner_service = ScannerService(
    settings_service=settings_service,
    strategy_service=strategy_service,
)
signals_service = SignalsService(
    settings_service=settings_service,
    strategy_service=strategy_service,
)
trade_service = TradeService(settings_service=settings_service)
manual_trade_service = ManualTradeService(
    settings_service=settings_service,
    bybit_service=bybit_service,
    trade_service=trade_service,
)
auto_trade_service = AutoTradeService(
    settings_service=settings_service,
    bybit_service=bybit_service,
    strategy_service=strategy_service,
    manual_trade_service=manual_trade_service,
    trade_service=trade_service,
)
dashboard_service = DashboardService(
    settings_service=settings_service,
    trade_service=trade_service,
)
chart_context_service = ChartContextService()
engine_service = EngineService(
    settings_service=settings_service,
    bybit_service=bybit_service,
)
